# Hours log, D1 document intake demo

| Date | Who | Hours | Work |
| --- | --- | ---: | --- |
| 2026-11-08 | Kem (agent) | 0.6 | Extraction, amount and date normalisation, arithmetic checks, dedupe, reconciliation, 17 tests, README |

A paid D1 build adds the OCR step, the client's numbering rules and the accounting write-back, which is where most of the 7 to 10 days go.
