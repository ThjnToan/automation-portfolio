#!/usr/bin/env python3
"""Tests for the D1 document intake demo. Run: python -m unittest discover -s tests -v"""
from __future__ import annotations

import csv
import sys
import unittest
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import parse_invoices as pi  # noqa: E402


class AmountTests(unittest.TestCase):
    def test_dot_thousands(self):
        self.assertEqual(pi.parse_amount("4.250.000"), 4_250_000)

    def test_single_dot_thousands(self):
        self.assertEqual(pi.parse_amount("233.600"), 233_600)

    def test_comma_thousands(self):
        self.assertEqual(pi.parse_amount("4,590,000"), 4_590_000)

    def test_currency_suffix(self):
        self.assertEqual(pi.parse_amount("10.152.000 d"), 10_152_000)

    def test_letters_inside_number_unreadable(self):
        self.assertIsNone(pi.parse_amount("3.153.6OO"))

    def test_empty_unreadable(self):
        self.assertIsNone(pi.parse_amount(""))


class DateTests(unittest.TestCase):
    def test_day_month_year(self):
        self.assertEqual(pi.parse_date("03/11/2026"), (date(2026, 11, 3), False))

    def test_two_digit_year_flagged(self):
        parsed, ambiguous = pi.parse_date("05/11/26")
        self.assertEqual(parsed, date(2026, 11, 5))
        self.assertTrue(ambiguous)

    def test_iso(self):
        self.assertEqual(pi.parse_date("2026-11-03"), (date(2026, 11, 3), False))


class BatchTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        data = ROOT / "sample"
        files = sorted(data.glob("invoice_*.txt"))
        cls.invoices = pi.dedupe([pi.extract(path) for path in files])
        count, total = pi.read_statement(data / "statement_total.txt")
        cls.stats = pi.write_outputs(cls.invoices, count, total, ROOT / "out")
        with (ROOT / "out" / "invoices.csv").open(encoding="utf-8") as fh:
            cls.rows = list(csv.DictReader(fh))

    def test_counts(self):
        self.assertEqual(self.stats["files"], 9)
        self.assertEqual(self.stats["counted"], 7)
        self.assertEqual(self.stats["unresolved"], 1)
        self.assertEqual(self.stats["duplicates"], 1)

    def test_totals_and_zero_gap(self):
        self.assertEqual(self.stats["parsed_sum"], 42_914_400)
        self.assertEqual(self.stats["implied_sum"], 3_153_600)
        self.assertEqual(self.stats["gap"], 0)

    def test_unreadable_total_gets_implied_value(self):
        row = next(r for r in self.rows if r["invoice_no"] == "DA-5521")
        self.assertEqual(row["status"], "unresolved")
        self.assertEqual(float(row["implied_total"]), 3_153_600)
        self.assertEqual(row["total"], "")

    def test_duplicate_excluded_from_totals(self):
        rows = [r for r in self.rows if r["status"] == "duplicate"]
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["invoice_no"], "TP-2026-1042")

    def test_missing_vat_line_is_review(self):
        row = next(r for r in self.rows if r["invoice_no"] == "VT-9014")
        self.assertEqual(row["status"], "review")
        self.assertIn("rounding", row["flags"])

    def test_two_digit_year_is_review(self):
        row = next(r for r in self.rows if r["invoice_no"] == "AN-7741")
        self.assertEqual(row["status"], "review")
        self.assertIn("two-digit year", row["flags"])

    def test_every_row_has_a_status(self):
        self.assertTrue(all(row["status"] for row in self.rows))

    def test_exceptions_name_the_unresolved_invoice(self):
        text = (ROOT / "out" / "exceptions.md").read_text(encoding="utf-8")
        self.assertIn("DA-5521", text)
        self.assertIn("confirm 3.153.600 d", text)


if __name__ == "__main__":
    unittest.main()
