# D1 document intake, portfolio demo

Invoice scans in, structured sheet and reconciliation out. This is the proof asset for offer **D1** (USD 700 to 1.200, 7 to 10 days): header fields extracted, arithmetic checked, unreadable scans flagged with the amount they should be, and the batch reconciled against an AP control total with a gap of zero.

Synthetic data only. No client data, no Manulife data.

## Run

```bash
python parse_invoices.py --data sample --out out
python -m unittest discover -s tests -v
```

Stdlib only, Python 3.10+.

## What it does

| Step | Detail |
| --- | --- |
| Read | OCR text per invoice, bilingual VN/EN labels |
| Extract | supplier, invoice number, date, subtotal, VAT, VAT rate, total |
| Normalise | dot or comma thousand separators, trailing VND or d, dd/mm/yyyy and two-digit years |
| Check | total against subtotal plus VAT, rounding tolerance 1.000 d, letters inside a number mean unreadable |
| Dedupe | same invoice number scanned twice is excluded from totals and reported |
| Reconcile | parsed total plus implied totals against the AP statement, unexplained gap printed |
| Output | `invoices.csv`, `exceptions.md`, `reconciliation.md` |

## Sample result

9 files, 8 unique invoices, 1 duplicate. 7 parsed with a total for 42.914.400 d, 1 unreadable total with an implied 3.153.600 d from subtotal plus VAT, unexplained gap 0 d against the 46.068.000 d statement. 1 invoice needs a human, 2 need a glance.

## Known limits, stated to the client

- Input is OCR text, not the raw PDF. Production adds an OCR step (Tesseract or a cloud OCR), which is where scan quality actually gets decided.
- The implied total assumes the VAT rate printed on the invoice. If the rate line is also unreadable, the row stays unresolved instead of guessing.
- Dedupe is by invoice number. Two suppliers reusing the same number would collide; the client's numbering scheme is checked before go-live.
- Arithmetic tolerance is 1.000 d. Larger differences go to review, not to the sheet as fact.
- No write-back to accounting software in this demo. Production posts the CSV or calls the client's API, and that mapping is agreed in scope.

## Files

```
parse_invoices.py       extraction, checks, dedupe, reconciliation
sample/invoice_*.txt    9 OCR-style invoices, one duplicate, one unreadable total
sample/statement_total.txt  AP control total
out/                    invoices.csv, exceptions.md, reconciliation.md
tests/test_parse.py     17 checks, no network
```
