#!/usr/bin/env python3
"""D1 document intake demo: scanned invoices in, structured sheet plus reconciliation out.

Reads OCR-style invoice text files, extracts the header fields, checks the
arithmetic, flags what a human must look at, and reconciles the batch against
a supplier statement total.

Stdlib only. Usage:
    python parse_invoices.py --data sample --out out
"""
from __future__ import annotations

import argparse
import csv
import re
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path

LABELS = {
    "vendor": ("supplier", "vendor", "seller", "nhà cung cấp", "nha cung cap"),
    "invoice_no": ("invoice no", "invoice number", "inv no", "số hóa đơn", "so hoa don"),
    "date": ("invoice date", "date", "ngày", "ngay"),
    "subtotal": ("subtotal", "sub total", "net amount", "cộng tiền hàng", "cong tien hang"),
    "vat": ("vat", "tax", "thuế gtgt", "thue gtgt"),
    "total": ("total", "grand total", "amount due", "tổng cộng", "tong cong"),
}
DATE_FORMATS = ("%d/%m/%Y", "%d/%m/%y", "%d.%m.%Y", "%Y-%m-%d", "%d-%m-%Y")
VAT_RATE_RE = re.compile(r"vat[^0-9]{0,6}(\d{1,2})\s*%|(\d{1,2})\s*%\s*vat", re.IGNORECASE)


@dataclass
class Invoice:
    file: str
    vendor: str = ""
    invoice_no: str = ""
    invoice_date: date | None = None
    subtotal: float | None = None
    vat: float | None = None
    vat_rate: float | None = None
    total: float | None = None
    implied_total: float | None = None
    confidence: str = "low"
    status: str = "review"
    flags: list[str] = field(default_factory=list)


def parse_amount(raw: str) -> float | None:
    """Parse a VND amount. Letters inside the number mean the scan is unreadable."""
    text = raw.strip()
    text = re.sub(r"(?i)\s*(vnd|₫|đ|d)\.?\s*$", "", text).strip()
    text = re.sub(r"(?i)^(vnd|₫|đ)\s*", "", text).strip()
    text = text.replace(" ", "").replace("₫", "")
    if not text or not re.search(r"\d", text):
        return None
    if re.search(r"[A-Za-z]", text):
        return None
    negative = text.startswith("-")
    text = text.lstrip("+-")
    if "." in text and "," in text:
        if text.rfind(",") > text.rfind("."):
            text = text.replace(".", "").replace(",", ".")
        else:
            text = text.replace(",", "")
    elif text.count(".") > 1:
        text = text.replace(".", "")
    elif text.count(".") == 1:
        head, _, tail = text.rpartition(".")
        text = head + tail if len(tail) == 3 and head else text
    elif text.count(",") > 1:
        text = text.replace(",", "")
    elif "," in text:
        head, _, tail = text.rpartition(",")
        text = f"{head}.{tail}" if len(tail) in (1, 2) else head + tail
    try:
        value = float(text)
    except ValueError:
        return None
    return -value if negative else value


def parse_date(raw: str) -> tuple[date | None, bool]:
    """Return (date, assumed_day_month). Two-digit years and ambiguous dd/mm are flagged."""
    text = raw.strip()
    for fmt in DATE_FORMATS:
        try:
            parsed = datetime.strptime(text, fmt).date()
        except ValueError:
            continue
        ambiguous = fmt.endswith("%y")
        return parsed, ambiguous
    return None, False


def vnd(value: float) -> str:
    return f"{value:,.0f}".replace(",", ".") + " d"


def split_line(line: str) -> tuple[str, str]:
    if ":" not in line:
        return "", ""
    label, _, value = line.partition(":")
    return label.strip().lower(), value.strip()


def extract(path: Path) -> Invoice:
    invoice = Invoice(file=path.name)
    text = path.read_text(encoding="utf-8")
    for line in text.splitlines():
        label, value = split_line(line)
        if not label:
            continue
        for key, words in LABELS.items():
            if not any(label == word or label.startswith(word) for word in words):
                continue
            if key == "vendor" and not invoice.vendor:
                invoice.vendor = value
            elif key == "invoice_no" and not invoice.invoice_no:
                invoice.invoice_no = value
            elif key == "date" and invoice.invoice_date is None:
                invoice.invoice_date, ambiguous = parse_date(value)
                if ambiguous:
                    invoice.flags.append("two-digit year in the date, read as 20xx, confirm on the paper copy")
            elif key == "subtotal" and invoice.subtotal is None:
                invoice.subtotal = parse_amount(value)
            elif key == "vat" and invoice.vat is None:
                invoice.vat = parse_amount(value)
            elif key == "total" and invoice.total is None:
                invoice.total = parse_amount(value)
            break

    rate = VAT_RATE_RE.search(text)
    if rate:
        invoice.vat_rate = float(rate.group(1) or rate.group(2))
    elif invoice.vat and invoice.subtotal:
        invoice.vat_rate = round(invoice.vat / invoice.subtotal * 100, 1)

    for field_name, label in (("vendor", "supplier"), ("invoice_no", "invoice number"),
                              ("invoice_date", "date"), ("total", "total")):
        if getattr(invoice, field_name) in (None, ""):
            invoice.flags.append(f"{label} missing")
    if invoice.total is None and invoice.subtotal is not None and invoice.vat is not None:
        invoice.implied_total = invoice.subtotal + invoice.vat
        invoice.flags.append(f"total unreadable, subtotal plus VAT implies {invoice.implied_total:,.0f}".replace(",", "."))
    if invoice.total is not None and invoice.subtotal is not None:
        expected = invoice.subtotal * (1 + (invoice.vat_rate or 0) / 100)
        difference = invoice.total - expected
        if abs(difference) >= 1000:
            invoice.flags.append(
                "total differs from subtotal plus VAT by " + f"{difference:,.0f}".replace(",", ".") + " d"
            )
        elif abs(difference) >= 1:
            invoice.flags.append("rounding difference of " + f"{difference:,.0f}".replace(",", ".") + " d")
    if invoice.subtotal is None and invoice.total is None:
        invoice.flags.append("no readable amount")

    core_missing = any(flag in ("supplier missing", "invoice number missing", "date missing") for flag in invoice.flags)
    no_total = invoice.total is None
    arithmetic = any("differs" in flag for flag in invoice.flags)
    if core_missing or no_total:
        invoice.confidence = "low"
        invoice.status = "unresolved"
    elif arithmetic:
        invoice.confidence = "medium"
        invoice.status = "review"
    elif invoice.flags:
        invoice.confidence = "medium"
        invoice.status = "review"
    else:
        invoice.confidence = "high"
        invoice.status = "ok"
    return invoice


def dedupe(invoices: list[Invoice]) -> list[Invoice]:
    seen: dict[str, Invoice] = {}
    for invoice in invoices:
        key = invoice.invoice_no.strip().upper()
        if not key:
            continue
        if key in seen:
            invoice.status = "duplicate"
            invoice.confidence = "n/a"
            invoice.flags.append(f"same invoice number as {seen[key].file}, excluded from totals")
            continue
        seen[key] = invoice
    return invoices


def read_statement(path: Path) -> tuple[int, float]:
    count, total = 0, 0.0
    if not path.exists():
        return count, total
    for line in path.read_text(encoding="utf-8").splitlines():
        label, value = split_line(line)
        if label.startswith("invoices"):
            count = int(re.sub(r"\D", "", value) or 0)
        elif label.startswith("total"):
            total = parse_amount(value) or 0.0
    return count, total


def write_outputs(invoices: list[Invoice], statement_count: int, statement_total: float, out_dir: Path) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    with (out_dir / "invoices.csv").open("w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(["file", "vendor", "invoice_no", "invoice_date", "subtotal", "vat", "total",
                         "implied_total", "confidence", "status", "flags"])
        for inv in invoices:
            writer.writerow([
                inv.file, inv.vendor, inv.invoice_no,
                inv.invoice_date.isoformat() if inv.invoice_date else "",
                f"{inv.subtotal:.0f}" if inv.subtotal is not None else "",
                f"{inv.vat:.0f}" if inv.vat is not None else "",
                f"{inv.total:.0f}" if inv.total is not None else "",
                f"{inv.implied_total:.0f}" if inv.implied_total is not None else "",
                inv.confidence, inv.status, "; ".join(inv.flags),
            ])

    counted = [inv for inv in invoices if inv.status in ("ok", "review") and inv.total is not None]
    unresolved = [inv for inv in invoices if inv.status == "unresolved"]
    duplicates = [inv for inv in invoices if inv.status == "duplicate"]
    parsed_sum = sum(inv.total for inv in counted)
    implied_sum = sum(inv.implied_total or 0 for inv in unresolved)
    gap = statement_total - parsed_sum - implied_sum

    exceptions = ["# Exceptions", ""]
    if not unresolved and not [inv for inv in invoices if inv.status == "review"]:
        exceptions.append("Nothing needs a human. Every invoice parsed clean and matched its arithmetic.")
    for inv in unresolved:
        exceptions.append(f"## {inv.file}: unresolved, {inv.vendor or 'unknown supplier'}")
        exceptions.append(f"- {inv.invoice_no or 'no invoice number'}, {inv.invoice_date or 'no date'}")
        for flag in inv.flags:
            exceptions.append(f"- {flag}")
        if inv.implied_total:
            exceptions.append(f"- action: confirm {vnd(inv.implied_total)} against the paper invoice before posting")
        exceptions.append("")
    for inv in invoices:
        if inv.status != "review":
            continue
        exceptions.append(f"## {inv.file}: review, {inv.vendor or 'unknown supplier'}")
        amount = vnd(inv.total) if inv.total is not None else "no total"
        exceptions.append(f"- {inv.invoice_no}, {amount}")
        for flag in inv.flags:
            exceptions.append(f"- {flag}")
        exceptions.append("")
    if duplicates:
        exceptions.append("## Duplicates excluded")
        for inv in duplicates:
            exceptions.append(f"- {inv.file}: {inv.invoice_no}, {inv.flags[-1] if inv.flags else ''}")
        exceptions.append("")
    (out_dir / "exceptions.md").write_text("\n".join(exceptions), encoding="utf-8")

    reconciliation = [
        "# Reconciliation",
        "",
        f"- Statement: {statement_count} invoices, {vnd(statement_total)}",
        f"- Files read: {len(invoices)}, unique invoices {len(invoices) - len(duplicates)}, duplicates {len(duplicates)}",
        f"- Parsed with a total: {len(counted)}, {vnd(parsed_sum)}",
        f"- Unresolved with an implied total: {len(unresolved)}, {vnd(implied_sum)}",
        f"- Unexplained gap: {vnd(gap)}",
        "",
        "Verdict: " + ("reconciled, every file accounts for its share" if abs(gap) < 1 else "gap needs a human"),
        "",
    ]
    (out_dir / "reconciliation.md").write_text("\n".join(reconciliation), encoding="utf-8")

    return {
        "files": len(invoices),
        "counted": len(counted),
        "unresolved": len(unresolved),
        "duplicates": len(duplicates),
        "parsed_sum": parsed_sum,
        "implied_sum": implied_sum,
        "gap": gap,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Turn invoice scans into a sheet and reconcile the batch.")
    parser.add_argument("--data", default="sample")
    parser.add_argument("--out", default="out")
    args = parser.parse_args()

    data_dir, out_dir = Path(args.data), Path(args.out)
    files = sorted(data_dir.glob("invoice_*.txt"))
    if not files:
        raise SystemExit(f"no invoice_*.txt files in {data_dir}")
    invoices = dedupe([extract(path) for path in files])
    statement_count, statement_total = read_statement(data_dir / "statement_total.txt")
    stats = write_outputs(invoices, statement_count, statement_total, out_dir)
    print(f"{stats['files']} files, {stats['counted']} with a total, {stats['unresolved']} unresolved, "
          f"{stats['duplicates']} duplicates")
    print(f"parsed {stats['parsed_sum']:,.0f}".replace(",", ".") + f" d, implied {stats['implied_sum']:,.0f}".replace(",", ".") + f" d, gap {stats['gap']:,.0f}".replace(",", ".") + " d")
    print(f"written: {out_dir / 'invoices.csv'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
