# Hours log, L1 lead inbox demo

| Date | Who | Hours | Work |
| --- | --- | ---: | --- |
| 2026-11-08 | Kem (agent) | 0.6 | Parser, sample data, screening and dedupe, digest, 16 tests, README |

Client-visible build time claim on the profile stays 4 to 6 days for L1; this demo is smaller than a paid build because the client's CRM write-back and scheduling are not included.
