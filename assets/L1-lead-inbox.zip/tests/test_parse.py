#!/usr/bin/env python3
"""Tests for the L1 lead inbox demo. Run: python -m unittest discover -s tests -v"""
from __future__ import annotations

import csv
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import parse_leads as pl  # noqa: E402


class NormalisationTests(unittest.TestCase):
    def test_email_lowercased_and_trimmed(self):
        self.assertEqual(pl.norm_email("  THU.HA@LienVietPack.vn "), "thu.ha@lienvietpack.vn")

    def test_double_at_rejected(self):
        self.assertEqual(pl.norm_email("quang.tran@@atlaslogistics.com"), "")

    def test_spelled_out_email_rejected(self):
        self.assertEqual(pl.norm_email("bob at example dot com"), "")

    def test_phone_local_format(self):
        self.assertEqual(pl.norm_phone("0905 123 456"), "0905123456")

    def test_phone_plus84_landline(self):
        self.assertEqual(pl.norm_phone("+84 28 3822 1234"), "02838221234")

    def test_phone_too_short_rejected(self):
        self.assertEqual(pl.norm_phone("12345"), "")


class ClassificationTests(unittest.TestCase):
    def test_weekly_report_beats_pdf_keyword(self):
        text = "Every Friday we merge two Excel exports by hand and email a PDF to six people"
        self.assertEqual(pl.classify_offer(text), "R1")

    def test_invoice_language_is_document_intake(self):
        self.assertEqual(pl.classify_offer("Supplier invoices arrive as scanned PDFs"), "D1")

    def test_lead_form_is_lead_inbox(self):
        self.assertEqual(pl.classify_offer("Our contact form sends leads to an inbox"), "L1")

    def test_unrelated_message_unmatched(self):
        self.assertEqual(pl.classify_offer("Do you do web design? We need a logo"), "")


class PipelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        source_dir = ROOT / "sample"
        leads = (
            pl.read_form(source_dir / "form_export.csv")
            + pl.read_dms(source_dir / "dms.txt")
            + pl.read_emails(source_dir / "emails.txt")
        )
        cls.leads = pl.screen(leads)
        cls.stats = pl.write_outputs(cls.leads, ROOT / "out")
        with (ROOT / "out" / "leads_clean.csv").open(encoding="utf-8") as fh:
            cls.valid = list(csv.DictReader(fh))
        with (ROOT / "out" / "rejected.csv").open(encoding="utf-8") as fh:
            cls.dropped = list(csv.DictReader(fh))

    def test_counts(self):
        self.assertEqual(self.stats, {"records": 24, "valid": 16, "dropped": 8})

    def test_three_channel_duplicate_collapses_to_one(self):
        ha = [row for row in self.valid if row["email"] == "thu.ha@lienvietpack.vn"]
        self.assertEqual(len(ha), 1)
        dups = [row for row in self.dropped if row["status"] == "duplicate"]
        self.assertEqual(len(dups), 3)

    def test_every_dropped_row_has_a_reason(self):
        self.assertTrue(all(row["reason"] for row in self.dropped))

    def test_every_valid_row_has_contact_and_offer(self):
        for row in self.valid:
            self.assertTrue(row["email"] or row["phone"] or row["handle"], row["lead_id"])
            self.assertIn(row["offer"], {"L1", "R1", "D1", "unmatched"})

    def test_clean_rows_are_unique(self):
        keys = [(row["email"] or row["phone"] or row["handle"]).lower() for row in self.valid]
        self.assertEqual(len(keys), len(set(keys)))

    def test_digest_written(self):
        digest = (ROOT / "out" / "digest.md").read_text(encoding="utf-8")
        self.assertIn("**16 new leads**", digest)
        self.assertIn("## Dropped", digest)


if __name__ == "__main__":
    unittest.main()
