# L1 lead inbox, portfolio demo

Three messy sources in, one clean sheet and a daily digest out. This is the proof asset for offer **L1** (USD 350 to 550, 4 to 6 days): a client's forms, DMs and enquiry emails normalised into one table, deduplicated across channels, spam removed, and a digest a manager reads in 30 seconds.

Synthetic data only. No client data, no Manulife data.

## Run

```bash
python parse_leads.py            # reads sample/, writes out/
python -m unittest discover -s tests -v
```

Stdlib only, Python 3.10+. No install step, no API keys.

## What it does

| Step | Detail |
| --- | --- |
| Read | website form CSV, pasted DMs (handle, channel, timestamp, text), forwarded emails |
| Normalise | emails lowercased and validated, phones reduced to VN format (`+84 28 3822 1234` becomes `02838221234`), names title-cased |
| Match offer | keyword scoring maps each lead to L1, R1 or D1, or leaves it unmatched |
| Screen | drops spam and off-topic pitches, rows with no usable contact, and duplicates |
| Dedupe | one key per lead across channels: email, else phone, else DM handle |
| Output | `leads_clean.csv`, `rejected.csv` with the reason on every row, `digest.md` |

## Sample result

24 records read, 16 valid, 8 dropped: 3 cross-channel duplicates of the same person (form, DM and email), 3 spam, 2 with no contact. Every dropped row carries the reason.

## Known limits, stated to the client

- Duplicate matching is exact on email, phone or handle. Same person under a different email and nickname is caught only by manual review; fuzzy matching is a change order.
- Offer matching is keyword scoring, not intent understanding. Anything unmatched is left for a human instead of being guessed.
- Email parsing handles forwarded plain text, not HTML-only mail with nested quotes.
- No CRM write-back in this demo. The production version posts to the client's sheet or CRM on a schedule.
- Phone formats are tuned for Vietnam. Another country needs its own rules file.

## Files

```
parse_leads.py        the pipeline
sample/               synthetic inputs, three sources
out/                  generated: clean sheet, rejects, digest
tests/test_parse.py   16 checks, no network
```
