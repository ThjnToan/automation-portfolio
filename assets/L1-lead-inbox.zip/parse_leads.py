#!/usr/bin/env python3
"""L1 lead inbox demo: three messy sources in, one clean sheet and a daily digest out.

Stdlib only, so it runs on any machine a client has. This is the portfolio
demo for offer L1 (lead inbox, USD 350 to 550, 4 to 6 days).

Inputs (sample/):
  form_export.csv  website form export
  dms.txt          pasted social DMs
  emails.txt       forwarded enquiry emails

Outputs (out/):
  leads_clean.csv  one row per real lead: contact, source, interest, offer match
  rejected.csv     duplicates, dead contacts and spam, with the reason
  digest.md        the daily summary a client actually reads
"""
from __future__ import annotations

import argparse
import csv
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
PHONE_RE = re.compile(r"(?:\+?84|0)(?:[\s.\-]?\d){8,10}")
SPAM_WORDS = ("seo services", "backlink", "crypto", "casino", "guest post", "web design offer")

OFFER_RULES = (
    ("L1", "lead inbox", ("lead", "form", "dm", "enquir", "inquir", "contact us", "crm")),
    ("R1", "weekly report", ("report", "báo cáo", "bao cao", "dashboard", "numbers", "merg", "consolidat", "weekly")),
    ("D1", "document intake", ("invoice", "hóa đơn", "hoa don", "receipt", "scan", "pdf", "retype", "digitis", "digitiz")),
)


@dataclass
class Lead:
    source: str
    created_at: str
    name: str
    email: str
    phone: str
    message: str
    handle: str = ""
    offer: str = ""
    status: str = "new"
    reason: str = ""


def squash(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "")).strip()


def norm_email(raw: str) -> str:
    candidate = squash(raw).lower().strip(".,;:<>()[]'\"")
    return candidate if EMAIL_RE.fullmatch(candidate) else ""


def norm_phone(raw: str) -> str:
    digits = re.sub(r"\D", "", raw or "")
    if digits.startswith("0084"):
        digits = digits[2:]
    if digits.startswith("84") and len(digits) > 9:
        digits = "0" + digits[2:]
    if digits and not digits.startswith("0"):
        digits = "0" + digits
    return digits if len(digits) in (10, 11) else ""


def norm_name(raw: str) -> str:
    name = squash(raw)
    name = re.sub(r"^[\"'<]+|[\"'>]+$", "", name)
    return name.title() if name else ""


def first_email(text: str) -> str:
    found = EMAIL_RE.search(text or "")
    return norm_email(found.group(0)) if found else ""


def first_phone(text: str) -> str:
    for found in PHONE_RE.finditer(text or ""):
        phone = norm_phone(found.group(0))
        if phone:
            return phone
    return ""


def classify_offer(message: str) -> str:
    """Pick the offer with the most keyword hits; ties go L1, then R1, then D1."""
    low = squash(message).lower()
    best_id, best_score = "", 0
    for offer_id, _label, words in OFFER_RULES:
        score = sum(1 for word in words if word in low)
        if score > best_score:
            best_id, best_score = offer_id, score
    return best_id


def read_form(path: Path) -> list[Lead]:
    leads: list[Lead] = []
    with path.open(newline="", encoding="utf-8-sig") as fh:
        for row in csv.DictReader(fh):
            message = squash(row.get("message", ""))
            leads.append(
                Lead(
                    source="web form",
                    created_at=squash(row.get("submitted_at", "")),
                    name=norm_name(row.get("full_name", "")),
                    email=norm_email(row.get("email", "")),
                    phone=norm_phone(row.get("phone", "")),
                    message=message,
                    offer=classify_offer(message),
                )
            )
    return leads


def read_dms(path: Path) -> list[Lead]:
    leads: list[Lead] = []
    block: dict[str, str] = {}
    for raw in path.read_text(encoding="utf-8").splitlines() + ["==="]:
        line = raw.strip()
        if line.lower() == "===" or not line:
            if block.get("text"):
                text = block["text"]
                handle = block.get("handle", "")
                email = first_email(text)
                name = norm_name(block.get("name") or "")
                if not name:
                    stem = email.split("@")[0] if email else handle.lstrip("@").replace(".", " ").replace("_", " ")
                    name = norm_name(stem)
                leads.append(
                    Lead(
                        source=block.get("channel", "dm"),
                        created_at=block.get("sent", ""),
                        name=name,
                        email=email,
                        phone=first_phone(text),
                        message=squash(text),
                        handle=handle,
                        offer=classify_offer(text),
                    )
                )
            block = {}
            continue
        key, _, value = line.partition(":")
        block[key.strip().lower()] = value.strip()
    return leads


def read_emails(path: Path) -> list[Lead]:
    leads: list[Lead] = []
    for chunk in re.split(r"\n--\s*\n", path.read_text(encoding="utf-8")):
        headers: dict[str, str] = {}
        body_lines: list[str] = []
        in_body = False
        for line in chunk.splitlines():
            if not in_body and ":" in line:
                key, _, value = line.partition(":")
                headers[key.strip().lower()] = value.strip()
                if key.strip().lower() == "body":
                    in_body = True
            else:
                in_body = True
                body_lines.append(line)
        if not headers:
            continue
        body = squash(" ".join(body_lines))
        from_raw = headers.get("from", "")
        email = first_email(from_raw) or first_email(body)
        name = norm_name(re.sub(r"<[^>]*>", "", from_raw)) or norm_name(email.split("@")[0])
        leads.append(
            Lead(
                source="email",
                created_at=headers.get("date", ""),
                name=name,
                email=email,
                phone=norm_phone(headers.get("phone", "")) or first_phone(body),
                message=body,
                offer=classify_offer(headers.get("subject", "") + " " + body),
            )
        )
    return leads


def screen(leads: list[Lead]) -> list[Lead]:
    """Attach status and reason: rejected, duplicate or valid."""
    seen: dict[str, Lead] = {}
    for lead in leads:
        low = lead.message.lower()
        if any(word in low for word in SPAM_WORDS):
            lead.status, lead.reason = "rejected", "spam or off-topic pitch"
            continue
        if not lead.email and not lead.phone and not lead.handle:
            lead.status, lead.reason = "rejected", "no usable contact channel"
            continue
        if lead.phone and not lead.email:
            # a phone is enough for a callback but not for the sheet digest, flag it
            lead.reason = "phone only"
        if lead.handle and not lead.email and not lead.phone:
            lead.reason = "reply by DM handle"
        key = (lead.email or lead.phone or lead.handle).lower()
        if key in seen:
            lead.status, lead.reason = "duplicate", f"duplicate of {seen[key].name or 'earlier lead'}"
            continue
        seen[key] = lead
        lead.status = "valid"
    return leads


def write_outputs(leads: list[Lead], out_dir: Path) -> dict[str, int]:
    out_dir.mkdir(parents=True, exist_ok=True)
    valid = [lead for lead in leads if lead.status == "valid"]
    rejected = [lead for lead in leads if lead.status != "valid"]

    with (out_dir / "leads_clean.csv").open("w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(["lead_id", "created_at", "name", "email", "phone", "handle", "source", "offer", "note", "message"])
        for index, lead in enumerate(valid, start=1):
            writer.writerow(
                [
                    f"L{index:03d}",
                    lead.created_at,
                    lead.name,
                    lead.email,
                    lead.phone,
                    lead.handle,
                    lead.source,
                    lead.offer or "unmatched",
                    lead.reason,
                    lead.message,
                ]
            )

    with (out_dir / "rejected.csv").open("w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(["source", "name", "email", "phone", "status", "reason", "message"])
        for lead in rejected:
            writer.writerow([lead.source, lead.name, lead.email, lead.phone, lead.status, lead.reason, lead.message])

    by_source: dict[str, int] = {}
    by_offer: dict[str, int] = {}
    for lead in valid:
        by_source[lead.source] = by_source.get(lead.source, 0) + 1
        by_offer[lead.offer or "unmatched"] = by_offer.get(lead.offer or "unmatched", 0) + 1

    lines = [
        f"# Lead digest, {datetime.now():%d %b %Y}",
        "",
        f"**{len(valid)} new leads**, {len(rejected)} dropped, {len(leads)} records read from {len(by_source)} sources.",
        "",
        "## By source",
        "",
        "| Source | Leads |",
        "| --- | ---: |",
        *(f"| {source} | {count} |" for source, count in sorted(by_source.items(), key=lambda kv: -kv[1])),
        "",
        "## By offer match",
        "",
        "| Offer | Leads |",
        "| --- | ---: |",
        *(f"| {offer} | {count} |" for offer, count in sorted(by_offer.items(), key=lambda kv: -kv[1])),
        "",
        "## New leads",
        "",
        "| # | Name | Contact | Source | Offer | First line |",
        "| ---: | --- | --- | --- | --- | --- |",
    ]
    for index, lead in enumerate(valid, start=1):
        contact = lead.email or lead.phone or lead.handle
        snippet = lead.message[:70] + ("..." if len(lead.message) > 70 else "")
        lines.append(f"| {index} | {lead.name or 'unknown'} | {contact} | {lead.source} | {lead.offer or '-'} | {snippet} |")
    lines += [
        "",
        "## Dropped",
        "",
        *([f"- {lead.name or 'unknown'} ({lead.source}): {lead.reason}" for lead in rejected] or ["- none"]),
        "",
    ]
    (out_dir / "digest.md").write_text("\n".join(lines), encoding="utf-8")

    return {"records": len(leads), "valid": len(valid), "dropped": len(rejected)}


def main() -> int:
    parser = argparse.ArgumentParser(description="Normalise form, DM and email leads into one sheet.")
    parser.add_argument("--input-dir", default="sample")
    parser.add_argument("--out-dir", default="out")
    args = parser.parse_args()

    source_dir = Path(args.input_dir)
    leads = read_form(source_dir / "form_export.csv") + read_dms(source_dir / "dms.txt") + read_emails(
        source_dir / "emails.txt"
    )
    stats = write_outputs(screen(leads), Path(args.out_dir))
    print(f"{stats['records']} records read, {stats['valid']} valid, {stats['dropped']} dropped")
    print(f"written: {Path(args.out_dir) / 'leads_clean.csv'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
