# Hours log, R1 weekly report demo

| Date | Who | Hours | Work |
| --- | --- | ---: | --- |
| 2026-11-08 | Kem (agent) | 0.5 | Loader, week comparison, HTML template, Chrome PDF path, 9 tests, README |

A paid R1 build is 5 to 8 days because the client's real exports, their schedule and their mail rule replace the sample files here.
