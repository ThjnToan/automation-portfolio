#!/usr/bin/env python3
"""R1 weekly report demo: three sources in, one report out, scheduled or on demand.

Reads a POS export, delivery platform payouts and labour hours, then writes a
one-page weekly report as HTML, plus a PDF when Chrome is available.

Stdlib only. Usage:
    python build_report.py --data sample --out out --pdf
"""
from __future__ import annotations

import argparse
import csv
import html
import shutil
import subprocess
import sys
from datetime import date, datetime, timedelta
from pathlib import Path

DAY_NAMES = ("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
CHROME_CANDIDATES = (
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    "/usr/bin/google-chrome",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
)


def money(value: float) -> str:
    return f"{value:,.0f}".replace(",", ".") + " d"


def pct(value: float) -> str:
    return f"{value:.1f}".replace(".", ",") + "%"


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        raise SystemExit(f"missing input: {path}")
    with path.open(newline="", encoding="utf-8-sig") as fh:
        return list(csv.DictReader(fh))


def load_pos(path: Path) -> tuple[dict[date, dict], list[str]]:
    daily: dict[date, dict] = {}
    issues: list[str] = []
    for row in read_csv(path):
        day = date.fromisoformat(row["date"].strip())
        if day in daily:
            issues.append(f"duplicate POS row for {day.isoformat()}, kept the last one")
        daily[day] = {"orders": int(row["orders"]), "gross": float(row["gross_vnd"])}
    return daily, issues


def load_delivery(path: Path) -> tuple[dict[date, dict], list[str]]:
    per_platform: dict[tuple[date, str], dict] = {}
    issues: list[str] = []
    for row in read_csv(path):
        day = date.fromisoformat(row["date"].strip())
        platform = row["platform"].strip()
        key = (day, platform)
        if key in per_platform:
            issues.append(f"duplicate {platform} row for {day.isoformat()}, kept the last one")
        payout = float(row["payout_vnd"])
        if payout < 0:
            issues.append(f"negative {platform} adjustment on {day.isoformat()}: {money(payout)}, included as refund")
        per_platform[key] = {"orders": int(row["orders"]), "payout": payout}
    daily: dict[date, dict] = {}
    for (day, _platform), values in per_platform.items():
        bucket = daily.setdefault(day, {"orders": 0, "payout": 0.0})
        bucket["orders"] += values["orders"]
        bucket["payout"] += values["payout"]
    return daily, issues


def load_labour(path: Path) -> tuple[dict[date, dict], list[str]]:
    daily: dict[date, dict] = {}
    issues: list[str] = []
    for row in read_csv(path):
        day = date.fromisoformat(row["date"].strip())
        if day in daily:
            issues.append(f"duplicate labour row for {day.isoformat()}, kept the last one")
        hours = float(row["hours"])
        daily[day] = {"hours": hours, "cost": hours * float(row["rate_vnd"])}
    return daily, issues


def window(start: date) -> list[date]:
    return [start + timedelta(days=offset) for offset in range(7)]


def summarise(pos: dict, delivery: dict, labour: dict, start: date) -> dict:
    days = []
    totals = {"pos_gross": 0.0, "pos_orders": 0, "payout": 0.0, "delivery_orders": 0, "hours": 0.0, "labour": 0.0}
    for day in window(start):
        pos_row = pos.get(day, {"orders": 0, "gross": 0.0})
        del_row = delivery.get(day, {"orders": 0, "payout": 0.0})
        lab_row = labour.get(day, {"hours": 0.0, "cost": 0.0})
        revenue = pos_row["gross"] + del_row["payout"]
        days.append(
            {
                "date": day,
                "pos_orders": pos_row["orders"],
                "pos_gross": pos_row["gross"],
                "delivery_orders": del_row["orders"],
                "payout": del_row["payout"],
                "revenue": revenue,
                "hours": lab_row["hours"],
                "labour": lab_row["cost"],
                "net_after_labour": revenue - lab_row["cost"],
            }
        )
        totals["pos_gross"] += pos_row["gross"]
        totals["pos_orders"] += pos_row["orders"]
        totals["payout"] += del_row["payout"]
        totals["delivery_orders"] += del_row["orders"]
        totals["hours"] += lab_row["hours"]
        totals["labour"] += lab_row["cost"]
    revenue = totals["pos_gross"] + totals["payout"]
    orders = totals["pos_orders"] + totals["delivery_orders"]
    totals.update(
        {
            "revenue": revenue,
            "orders": orders,
            "avg_ticket": revenue / orders if orders else 0.0,
            "labour_share": totals["labour"] / revenue * 100 if revenue else 0.0,
            "delivery_share": totals["payout"] / revenue * 100 if revenue else 0.0,
            "net_after_labour": revenue - totals["labour"],
        }
    )
    gaps = [d.isoformat() for d in window(start) if d not in pos]
    return {"start": start, "end": start + timedelta(days=6), "days": days, "totals": totals, "gaps": gaps}


def delta(this: float, last: float) -> tuple[str, str]:
    """Return (formatted change, css class)."""
    if not last:
        return "n/a", "flat"
    change = (this - last) / last * 100
    css = "good" if change > 0.05 else "bad" if change < -0.05 else "flat"
    return f"{change:+.1f}".replace(".", ",") + "%", css


def build_html(current: dict, previous: dict, issues: list[str], client: str) -> str:
    now = datetime.now().strftime("%d %b %Y %H:%M")
    rows = []
    for day in current["days"]:
        rows.append(
            "<tr>"
            f"<td class='day'>{day['date'].strftime('%a %d %b')}</td>"
            f"<td class='num'>{day['pos_orders']}</td>"
            f"<td class='num'>{money(day['pos_gross'])}</td>"
            f"<td class='num'>{day['delivery_orders']}</td>"
            f"<td class='num'>{money(day['payout'])}</td>"
            f"<td class='num strong'>{money(day['revenue'])}</td>"
            f"<td class='num'>{day['hours']:.0f}</td>"
            f"<td class='num'>{money(day['labour'])}</td>"
            f"<td class='num'>{money(day['net_after_labour'])}</td>"
            "</tr>"
        )

    cur, prev = current["totals"], previous["totals"]
    kpis = [
        ("Net sales", money(cur["revenue"]), *delta(cur["revenue"], prev["revenue"])),
        ("Orders", f"{cur['orders']:,}".replace(",", "."), *delta(cur["orders"], prev["orders"])),
        ("Average ticket", money(cur["avg_ticket"]), *delta(cur["avg_ticket"], prev["avg_ticket"])),
        ("Labour cost", money(cur["labour"]), *delta(cur["labour"], prev["labour"])),
        ("Labour share of sales", pct(cur["labour_share"]), "target 22%", "flat"),
        ("Delivery share", pct(cur["delivery_share"]), *delta(cur["delivery_share"], prev["delivery_share"])),
    ]
    cards = "\n".join(
        f"<div class='card'><div class='label'>{label}</div><div class='value'>{value}</div>"
        f"<div class='delta {css}'>{note}</div></div>"
        for label, value, note, css in kpis
    )

    comparison = [
        ("Net sales", cur["revenue"], prev["revenue"], money),
        ("Orders", cur["orders"], prev["orders"], lambda v: f"{v:,.0f}".replace(",", ".")),
        ("Average ticket", cur["avg_ticket"], prev["avg_ticket"], money),
        ("Labour cost", cur["labour"], prev["labour"], money),
        ("Net after labour", cur["net_after_labour"], prev["net_after_labour"], money),
    ]
    compare_rows = "\n".join(
        f"<tr><td>{label}</td><td class='num'>{fmt(value)}</td><td class='num'>{fmt(last)}</td>"
        f"<td class='num {delta(value, last)[1]}'>{delta(value, last)[0]}</td></tr>"
        for label, value, last, fmt in comparison
    )

    gaps = current["gaps"]
    checks = list(issues)
    if gaps:
        checks.append("no POS rows for " + ", ".join(gaps) + "; treated as zero")
    if not checks:
        checks.append("no gaps, duplicates or negative adjustments found in this window")

    return f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Weekly ops report, {current['start'].isoformat()} to {current['end'].isoformat()}</title>
<style>
:root {{
  --bg:#F4F6F8; --card:#FFFFFF; --ink:#101828; --ink2:#475467; --ink3:#98A2B3;
  --line:#EAECF0; --accent:#0F766E; --soft:#ECFDF5; --good:#16A34A; --bad:#F04438;
  --warn:#B54708; --warn-soft:#FFFAEB; --shadow:0 1px 2px rgba(16,24,40,.05),0 8px 20px -8px rgba(16,24,40,.10);
}}
* {{ box-sizing:border-box; margin:0; padding:0; }}
body {{ background:var(--bg); color:var(--ink); font-family:"Segoe UI",Roboto,Arial,sans-serif;
  font-size:14px; line-height:1.55; font-variant-numeric:tabular-nums; padding:0; }}
.page {{ max-width:1120px; margin:0 auto; padding:28px 24px 60px; }}
.hero {{ display:flex; justify-content:space-between; align-items:flex-end; gap:24px; flex-wrap:wrap;
  background:linear-gradient(180deg,#F0FDFA 0%,#FFFFFF 60%); border:1px solid var(--line);
  border-top:4px solid var(--accent); border-radius:10px; box-shadow:var(--shadow); padding:24px 28px; }}
.eyebrow {{ font-size:11px; font-weight:700; letter-spacing:.14em; text-transform:uppercase; color:var(--accent); }}
h1 {{ font-size:28px; font-weight:800; letter-spacing:-.02em; margin-top:6px; }}
.meta {{ color:var(--ink2); font-size:12.5px; margin-top:8px; }}
.badge {{ background:var(--soft); color:var(--accent); border:1px solid #CCFBF1; border-radius:999px;
  padding:5px 11px; font-size:12px; font-weight:600; white-space:nowrap; }}
.grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(165px,1fr)); gap:12px; margin:16px 0 22px; }}
.card {{ background:var(--card); border:1px solid var(--line); border-radius:10px; box-shadow:var(--shadow); padding:14px 16px; }}
.label {{ font-size:12px; color:var(--ink2); }}
.value {{ font-size:21px; font-weight:800; margin-top:4px; letter-spacing:-.01em; }}
.delta {{ font-size:12px; font-weight:600; margin-top:3px; }}
.good {{ color:var(--good); }} .bad {{ color:var(--bad); }} .flat {{ color:var(--ink3); }}
.panel {{ background:var(--card); border:1px solid var(--line); border-radius:10px; box-shadow:var(--shadow); padding:18px 20px; margin-bottom:18px; }}
h2 {{ font-size:16px; font-weight:700; margin-bottom:12px; }}
table {{ width:100%; border-collapse:collapse; font-size:13px; }}
th {{ text-align:left; font-size:11.5px; text-transform:uppercase; letter-spacing:.06em; color:var(--ink3);
  border-bottom:1px solid var(--line); padding:8px 6px; font-weight:700; }}
td {{ padding:8px 6px; border-bottom:1px solid #F2F4F7; }}
.num {{ text-align:right; white-space:nowrap; }}
.strong {{ font-weight:700; }}
.day {{ color:var(--ink2); white-space:nowrap; }}
ul {{ margin-left:18px; color:var(--ink2); }}
li {{ margin:4px 0; }}
footer {{ color:var(--ink3); font-size:12px; margin-top:22px; }}
</style></head><body><div class="page">
<div class="hero">
  <div>
    <div class="eyebrow">Weekly operations report</div>
    <h1>{client}, {current['start'].strftime('%d %b')} to {current['end'].strftime('%d %b %Y')}</h1>
    <div class="meta">Generated {now} from POS export, delivery payouts and labour hours. Synthetic sample data.</div>
  </div>
  <div class="badge">Week {current['start'].isocalendar()[1]:02d}</div>
</div>

<div class="grid">{cards}</div>

<div class="panel">
  <h2>Week on week</h2>
  <table>
    <thead><tr><th>Metric</th><th class="num">This week</th><th class="num">Last week</th><th class="num">Change</th></tr></thead>
    <tbody>{compare_rows}</tbody>
  </table>
</div>

<div class="panel">
  <h2>Daily detail</h2>
  <table>
    <thead><tr><th>Day</th><th class="num">POS orders</th><th class="num">POS sales</th>
    <th class="num">Delivery orders</th><th class="num">Delivery payout</th><th class="num">Net sales</th>
    <th class="num">Labour h</th><th class="num">Labour cost</th><th class="num">Net after labour</th></tr></thead>
    <tbody>{''.join(rows)}</tbody>
  </table>
</div>

<div class="panel">
  <h2>Data checks</h2>
  <ul>{''.join(f'<li>{html.escape(check)}</li>' for check in checks)}</ul>
</div>

<footer>Sources: pos_sales.csv, delivery_payouts.csv, labour_hours.csv. Method: per-day rows joined on date, one row per source per day,
labour cost = hours x rate. Run: python build_report.py --data sample --out out --pdf</footer>
</div></body></html>"""


def find_chrome() -> str | None:
    for candidate in CHROME_CANDIDATES:
        if Path(candidate).exists():
            return candidate
    return shutil.which("chrome") or shutil.which("google-chrome")


def print_pdf(html_path: Path, pdf_path: Path) -> bool:
    chrome = find_chrome()
    if not chrome:
        return False
    result = subprocess.run(
        [
            chrome,
            "--headless=new",
            "--disable-gpu",
            "--no-pdf-header-footer",
            f"--print-to-pdf={pdf_path.resolve()}",
            html_path.resolve().as_uri(),
        ],
        capture_output=True,
        text=True,
        timeout=90,
    )
    return result.returncode == 0 and pdf_path.exists()


def main() -> int:
    parser = argparse.ArgumentParser(description="Build the R1 weekly operations report.")
    parser.add_argument("--data", default="sample")
    parser.add_argument("--out", default="out")
    parser.add_argument("--client", default="Sample Cafe")
    parser.add_argument("--week-end", help="Any date in the reporting week, default is the latest date in the data")
    parser.add_argument("--pdf", action="store_true", help="Also print a PDF, needs Chrome")
    args = parser.parse_args()

    data_dir, out_dir = Path(args.data), Path(args.out)
    pos, issues_pos = load_pos(data_dir / "pos_sales.csv")
    delivery, issues_del = load_delivery(data_dir / "delivery_payouts.csv")
    labour, issues_lab = load_labour(data_dir / "labour_hours.csv")

    latest = max(set(pos) | set(delivery) | set(labour))
    anchor = date.fromisoformat(args.week_end) if args.week_end else latest
    start = anchor - timedelta(days=anchor.weekday())
    current = summarise(pos, delivery, labour, start)
    previous = summarise(pos, delivery, labour, start - timedelta(days=7))

    issues = issues_pos + issues_del + issues_lab
    out_dir.mkdir(parents=True, exist_ok=True)
    html_path = out_dir / "weekly_report.html"
    html_path.write_text(build_html(current, previous, issues, args.client), encoding="utf-8")

    print(f"week {start} to {start + timedelta(days=6)}")
    print(f"net sales {money(current['totals']['revenue'])}, orders {current['totals']['orders']}, "
          f"labour {pct(current['totals']['labour_share'])} of sales")
    print(f"issues: {len(issues)}")
    print(f"written: {html_path}")

    if args.pdf:
        pdf_path = out_dir / "weekly_report.pdf"
        if not find_chrome():
            print("pdf: skipped, Chrome not found; the HTML is the deliverable", file=sys.stderr)
        elif print_pdf(html_path, pdf_path):
            print(f"written: {pdf_path}")
        else:
            print("pdf: Chrome ran but wrote nothing; keep the HTML and rerun with --pdf", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
