# R1 weekly report, portfolio demo

Three sources in, one report out: POS export, delivery payouts and labour hours combined into a single weekly page with week-on-week deltas, daily detail and a data-checks section. This is the proof asset for offer **R1** (USD 450 to 800, 5 to 8 days).

Synthetic data only. No client data, no Manulife data.

## Run

```bash
python build_report.py --data sample --out out --pdf
python -m unittest discover -s tests -v
```

Stdlib only. `--pdf` needs Chrome installed; without it the HTML is the deliverable.

## What it does

| Step | Detail |
| --- | --- |
| Read | three CSVs, one row per source per day |
| Clean | duplicate dates dropped and reported, negative payout adjustments kept as refunds and reported |
| Join | per-day rows joined on date, labour cost = hours x rate |
| Compare | current week against the previous week, Monday to Sunday |
| Flag | missing days, duplicates, negative values, rounding |
| Output | `weekly_report.html`, `weekly_report.pdf` when Chrome is present |

## Sample result

Week 2026-11-02 to 2026-11-08: net sales 45.690.000 d, 1.017 orders, labour 21,3% of sales, labour cost up 2,4% while sales fell 0,9%. Two data issues caught: a duplicate POS row and a negative delivery adjustment.

## Scheduling

The script is the whole job, so the schedule is a cron or Task Scheduler line, not code:

```
# every Monday 07:00, then the client's mail rule sends the PDF
0 7 * * 1 cd /path/to/report && python build_report.py --data data --out out --pdf
```

## Known limits, stated to the client

- One currency, one timezone. Multi-currency needs an FX table and a stated rate date.
- Weeks are Monday to Sunday. A client on a different cut-off needs a config value, quoted separately.
- PDF comes from Chrome printing the HTML. On a machine without Chrome the report stays HTML.
- The script assumes the three exports keep their column names. A changed export is a mapping edit in `load_*`, not a rebuild.
- Email delivery is not built in; it is a mail rule or a two-line SMTP call in the client's environment.

## Files

```
build_report.py       the pipeline and the template
sample/               pos_sales.csv, delivery_payouts.csv, labour_hours.csv
out/                  weekly_report.html, weekly_report.pdf
tests/test_build.py   9 checks, no network
```
