#!/usr/bin/env python3
"""Tests for the R1 weekly report demo. Run: python -m unittest discover -s tests -v"""
from __future__ import annotations

import sys
import unittest
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import build_report as br  # noqa: E402


class FormatTests(unittest.TestCase):
    def test_money_uses_dot_separators(self):
        self.assertEqual(br.money(45_690_000), "45.690.000 d")

    def test_delta_good_bad_flat(self):
        self.assertEqual(br.delta(110, 100)[1], "good")
        self.assertEqual(br.delta(90, 100)[1], "bad")
        self.assertEqual(br.delta(100, 100)[1], "flat")

    def test_delta_without_last_week(self):
        self.assertEqual(br.delta(100, 0), ("n/a", "flat"))


class DataTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        data = ROOT / "sample"
        cls.pos, cls.pos_issues = br.load_pos(data / "pos_sales.csv")
        cls.delivery, cls.del_issues = br.load_delivery(data / "delivery_payouts.csv")
        cls.labour, cls.lab_issues = br.load_labour(data / "labour_hours.csv")
        cls.current = br.summarise(cls.pos, cls.delivery, cls.labour, date(2026, 11, 2))
        cls.previous = br.summarise(cls.pos, cls.delivery, cls.labour, date(2026, 10, 26))

    def test_duplicate_pos_row_flagged_and_deduped(self):
        self.assertEqual(len(self.pos_issues), 1)
        self.assertIn("duplicate", self.pos_issues[0])

    def test_negative_adjustment_flagged_and_included(self):
        self.assertTrue(any("negative" in issue for issue in self.del_issues))
        self.assertEqual(self.current["totals"]["payout"], 9_840_000)

    def test_week_totals(self):
        totals = self.current["totals"]
        self.assertEqual(totals["revenue"], 45_690_000)
        self.assertEqual(totals["orders"], 1017)
        self.assertEqual(totals["labour"], 9_728_000)
        self.assertAlmostEqual(totals["labour_share"], 21.3, places=1)

    def test_previous_week_totals(self):
        self.assertEqual(self.previous["totals"]["revenue"], 46_100_000)

    def test_no_missing_days(self):
        self.assertEqual(self.current["gaps"], [])

    def test_html_contains_headline_numbers(self):
        html = br.build_html(self.current, self.previous, self.pos_issues + self.del_issues, "Sample Cafe")
        self.assertIn("45.690.000", html)
        self.assertIn("Week on week", html)
        self.assertIn("Sample Cafe", html)
        self.assertIn("duplicate POS row", html)


if __name__ == "__main__":
    unittest.main()
